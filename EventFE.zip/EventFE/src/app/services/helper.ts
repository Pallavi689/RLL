let baseUrl="http://localhost:9092";
export default baseUrl;

export class FoodItem{
    foodItemId:any;
    foodItemName:any;
    foodItemCost:any;
    venueId:any;
}