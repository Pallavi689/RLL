import { CommonModule } from '@angular/common';
import { AdminBookingServiceService } from './../../../services/adminService/adminBookingService/admin-booking-service.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-bookings-admin',  
  imports: [CommonModule,RouterModule,FormsModule],
  templateUrl: './view-bookings-admin.component.html',
  styleUrls: ['./view-bookings-admin.component.css']
})
export class ViewBookingsAdminComponent implements OnInit {

  constructor(private bookingService : AdminBookingServiceService) { }

  bookings:any;
  ngOnInit(): void {

    // Get All Bookings
    this.bookingService.getAllBookings().subscribe(
      (data)=>{
        this.bookings = data;
      },
      (error)=>{
        Swal.fire("Error","Error in Loading Booking Data","error");
      }
    )
  }

}
