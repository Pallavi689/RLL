import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { VenueUserService } from '../../../services/userService/venuesUser/venue-user.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-view-venues-admin',  
  imports: [CommonModule,RouterModule,FormsModule],
  templateUrl: './view-venues-admin.component.html',
  styleUrls: ['./view-venues-admin.component.css']
})
export class ViewVenuesAdminComponent implements OnInit {

  venues:any;
  constructor(private venueUserService:VenueUserService) { }

  ngOnInit(): void {
    // Get All Venues
    this.venueUserService.getAllVenues().subscribe(
      (venues)=>{
        this.venues = venues;
      },
      (error)=>{
        Swal.fire("Error","Problem in loading Venues","error");
      }
      )
  }


}
