import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { MemberService } from '../../../services/member.service';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-organizer',  
  imports: [CommonModule,RouterModule,FormsModule],
  templateUrl: './view-organizer.component.html',
  styleUrls: ['./view-organizer.component.css']
})
export class ViewOrganizerComponent implements OnInit {

  organizers:any;
  constructor(private memberService : MemberService) { }

  // Get All Organizers
  ngOnInit(): void {
    this.memberService.getAllOrganizers().subscribe(
      (data)=>{
        this.organizers = data;
      },
      (error)=>{
        console.log(error);
      }
    )
  }

  }

