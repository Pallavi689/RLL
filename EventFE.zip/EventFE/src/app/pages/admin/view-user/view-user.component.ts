import { Component, OnInit } from '@angular/core';
import { MemberService } from '../../../services/member.service';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-user',  
  imports: [CommonModule,RouterModule,FormsModule],
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  users:any;
  constructor(private memberService : MemberService) { }

  ngOnInit(): void {
    // Get All Users
    this.memberService.getAllUsers().subscribe(
      (data)=>{
        this.users = data;
      },
      (error)=>{
        console.log(error);
      }
    )
  }

}
