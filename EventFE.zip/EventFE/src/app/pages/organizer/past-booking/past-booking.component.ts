import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { OrganizerService } from '../../../services/organizerService/organizer.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-past-booking',  
  imports: [RouterModule,CommonModule],
  templateUrl: './past-booking.component.html',
  styleUrls: ['./past-booking.component.css']
})
export class PastBookingComponent implements OnInit {

  bookings:any;
  constructor(private orgService : OrganizerService) { }

  // Past Booking
  ngOnInit(): void {
    this.orgService.getPastBookingsByOrgId().subscribe(
      (data)=>{
        this.bookings = data;
      },
      (error)=>{
        Swal.fire("Error","Error in Loading Booking Data","error");
      }
    )
  }

}
