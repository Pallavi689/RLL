import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SidebarOrgComponent } from '../../../components/sidebar-org/sidebar-org.component';
import { Navbar2Component } from '../../../components/navbar2/navbar2.component';

@Component({
  selector: 'app-organizer-dashboard',  
  imports: [RouterModule,CommonModule,SidebarOrgComponent,Navbar2Component],
  templateUrl: './organizer-dashboard.component.html',
  styleUrls: ['./organizer-dashboard.component.css']
})
export class OrganizerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
