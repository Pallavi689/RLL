import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-pay-message',  
  imports: [RouterModule],
  templateUrl: './pay-message.component.html',
  styleUrls: ['./pay-message.component.css']
})
export class PayMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
