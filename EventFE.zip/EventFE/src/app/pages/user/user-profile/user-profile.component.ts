import { Component, OnInit } from '@angular/core';
import { MemberService } from '../../../services/member.service';

@Component({
  selector: 'app-user-profile',  
  imports: [],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  memberId:any;
  member:any;
  constructor(private memberService : MemberService) { }

  ngOnInit(): void {
    this.memberId = localStorage.getItem('memberId');

    this.memberService.getMember(this.memberId).subscribe(
      (data)=>{  this.member= data },
      (error)=>{ console.log(error) }
    )
  }

}
