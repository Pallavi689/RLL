import { ActivatedRoute, RouterModule } from '@angular/router';
import { HistoryService } from './../../../services/userService/history.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-availability',  
  imports: [FormsModule,RouterModule,CommonModule],
  templateUrl: './availability.component.html',
  styleUrls: ['./availability.component.css']
})
export class AvailabilityComponent implements OnInit {

  venueId:any;
  dates:any;
  constructor(private historyService:HistoryService, private route : ActivatedRoute) { }

  ngOnInit(): void {

    this.venueId = this.route.snapshot.params['venueId'];
    this.historyService.getDates(this.venueId).subscribe(
      (dates)=>{
        this.dates = dates;
      },
      (error)=>{
        console.log(error);
      }
    )
  }

}
