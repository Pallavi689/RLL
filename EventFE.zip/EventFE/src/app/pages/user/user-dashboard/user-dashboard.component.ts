import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SidebarComponent } from '../../../components/sidebar/sidebar.component';
import { Navbar2Component } from '../../../components/navbar2/navbar2.component';

@Component({
  selector: 'app-user-dashboard',  
  imports: [RouterModule,CommonModule,SidebarComponent,Navbar2Component],
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
